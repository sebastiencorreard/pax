/*
$Id: IconDisplay.java,v 1.3 2003/02/18 11:48:46 sander Exp $
*/


/*
Copyright (C) 2001-2002 Mainline Project (I3S - ESSI - CNRS -UNSA)

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

For further information on the GNU Lesser General Public License,
see: http://www.gnu.org/copyleft/lesser.html
For further information on this library, contact: mainline@essi.fr
*/


package fr.ove.openmath.jome.ctrlview.bidim;

import fr.ove.openmath.jome.ctrlview.bidim.*;
import fr.ove.openmath.jome.model.*;

/**
* The display of a symbol.
*
* @author � 2000 DIRAT Laurent
* @version 2.0  05/01/2000
*/
public class IconDisplay extends SymbolDisplay {
    /**
    * The constructor.<BR>
    * Instanciate a new display, with no displayable symbol associated. The symbol has to be set
    * by hand.
    * @param graphicContext the graphic context of the display.
    */
    public IconDisplay(GraphicContext graphicContext) {
        super(graphicContext);
        IconLayout layout = new IconLayout();
        layout.initDisplay(this);
        setLayout(layout);
    }
    
    /**
    * Builds the display of the formula tree structure.<BR>
    * This method has to be called when a formula tree structure has been created and the 
    * displays have not been associated yet.<BR>
    * As a prerequesit, the instance which call this method MUST have a corresponding instance
    * (a listener) in the formula tree structure (i.e. the formula tree structure we want to display).<BR>
    *
    public void buildDisplay() {
        Display childDisplay;
        FormulaTreeStructure ftsChild;
        Icon fts;
        int count;
        SubstitutedDisplayManager iconLM = (SubstitutedDisplayManager) getLayout();
        
        // On r�cup�re l'�l�ment de la FTS donc l'instance est le display.
        fts = (Icon) getListener();
        if (fts != null) { // Bon malgr� le pr�requis, on fait le test quand m�me
            count = fts.getNbIconified();
            
            // On parcourre la liste des fils de la fts, pour leur associer le display qui va bien
            for (int i = 0; i < count; i++) {
                ftsChild = (FormulaTreeStructure) fts.getIconified(i);
                // Allocation du display
                childDisplay = getDisplayAllocator().allocateDisplay(getGraphicContext(), ftsChild);
                // On ajoute le nouveau display dans la liste des displays iconifi�s
                iconLM.addSubstitutedDisplay(childDisplay);
                // On descend dans la fts pour poursuivre la construction des display
                childDisplay.buildDisplay();
            }
        }
    }
    */
}

