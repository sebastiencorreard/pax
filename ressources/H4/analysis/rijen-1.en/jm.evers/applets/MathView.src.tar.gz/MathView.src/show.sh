#!/bin/sh

cd build/classes
#appletviewer 2.html
mozilla file://`pwd`/1.html
#appletviewer 1.html
